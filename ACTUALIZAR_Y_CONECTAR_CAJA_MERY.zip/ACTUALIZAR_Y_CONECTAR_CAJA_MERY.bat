<# :
@echo off
title Actualizar y conectar la Caja Mery
set "CAJA_BAT=%~f0"
set "CAJA_PASO="
if /i "%~1"=="conectar" set "CAJA_PASO=conectar"
if /i "%~1"=="conectar" set "CAJA_DIR=%~2"
if /i "%~1"=="conectar" set "CAJA_RESULTADO=%~3"
if /i "%~1"=="conectar" title Conectar la Caja Mery para que Nico entre a distancia
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:CAJA_BAT); Invoke-Expression $s"
set "RC=%errorlevel%"
if /i not "%CAJA_PASO%"=="conectar" goto :fin
if "%RC%"=="0" timeout /t 8
if not "%RC%"=="0" pause
exit %RC%
:fin
echo.
pause
exit /b
#>

# ---------------------------------------------------------------------------
# ACTUALIZAR Y CONECTAR la Caja Mery: un solo archivo para el local.
# Doble clic en cada PC del local que tenga la Caja Mery:
#  - En la PC PRINCIPAL (la que tiene la base):
#     1. La deja lista para que Nico entre a distancia con Tailscale (en otra
#        ventana, con permiso de administrador). Es lo mismo que hace
#        CONECTAR_A_DISTANCIA.bat.
#     2. Actualiza la Caja Mery a la ultima version y la vuelve a abrir. Es lo
#        mismo que hace ACTUALIZAR_CAJA_MERY.bat. Va despues de la conexion
#        para que la caja se reinicie una sola vez.
#     3. Le avisa a Nico por Telegram (bot del local) como quedo todo.
#  - En una caja SECUNDARIA solo la actualiza.
# No toca ventas ni datos de la base. Se puede abrir mas de una vez.
# Prueba: CAJA_PRUEBA=1 (no instala, no toca firewall ni registro, no manda
# Telegram, no pide administrador y no abre el programa; CAJA_TS apunta a un
# tailscale falso y CAJA_CONFIRMA contesta las preguntas).
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072 } catch {}

$PASO        = [string]$env:CAJA_PASO
$PRUEBA      = [bool]$env:CAJA_PRUEBA
$OWNER       = 'ncreativos'
$REPO        = 'caja-mery-updates'
$MASTER_CHAT = '406001767'
# Huellas (sha256) de la cuenta de Tailscale de Nico y de la clave de red de
# fabrica. Este archivo se baja de internet: no lleva ninguna de las dos.
$HUELLA_RED_NICO = '183943f4c01b3fdb922fcda864b1b293aca51d93600eeb72f9ef837c7298c565'
$HUELLA_CLAVE    = '6f296e00063bacb0dc70a772140867f2493ab1b61b1094adf439b80cbc308f08'
$REGLA_FW    = 'Caja Mery - Nico a distancia'
$PUERTO_CAJA = 5555
$TS          = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
if ($env:CAJA_TS) { $TS = $env:CAJA_TS }
$LOCALES = @{
    'guernica'   = @{ nombre = 'La Previa';   equipo = 'mery-laprevia' }
    'delah'      = @{ nombre = 'De La H';     equipo = 'mery-delah' }
    'korn'       = @{ nombre = 'Korn';        equipo = 'mery-korn' }
    'sanvicente' = @{ nombre = 'San Vicente'; equipo = 'mery-sanvicente' }
}
$script:BOT     = $null
$script:LOCAL   = 'este local'
$script:logFile = Join-Path $env:TEMP 'actualizar_conectar_caja_mery_log.txt'

$CURL = Join-Path $env:SystemRoot 'System32\curl.exe'
if (-not (Test-Path -LiteralPath $CURL)) { $CURL = $null }

# Texto con acentos y emojis para Telegram (el archivo es ASCII: \u00e1 = a con tilde)
function T($s) { return [regex]::Unescape($s) }

function Log($m) {
    Write-Host $m
    try { Add-Content -Path $script:logFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m) } catch {}
}

function Huella($texto) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $b = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes([string]$texto))
    return (($b | ForEach-Object { $_.ToString('x2') }) -join '')
}

function Telegram($texto) {
    if (-not $script:BOT) { return $false }
    if ($PRUEBA) {
        Write-Host ''
        Write-Host '[PRUEBA] Mensaje para Nico por Telegram:' -ForegroundColor DarkGray
        Write-Host $texto -ForegroundColor DarkGray
        try { [IO.File]::AppendAllText((Join-Path $env:TEMP 'mery_distancia_telegram.txt'), $texto + "`r`n-----`r`n", (New-Object Text.UTF8Encoding($false))) } catch {}
        return $true
    }
    try {
        $json = @{ chat_id = $MASTER_CHAT; text = $texto; disable_web_page_preview = $true } | ConvertTo-Json -Compress
        $r = Invoke-RestMethod -Method Post -Uri ('https://api.telegram.org/bot' + $script:BOT + '/sendMessage') `
             -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 25
        return [bool]$r.ok
    } catch { return $false }
}

function Buscar-Exe {
    $c = @()
    $c += (Join-Path (Split-Path -Parent $env:CAJA_BAT) 'CajaMeryJane.exe')
    try {
        Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'CajaMery*' } |
            ForEach-Object { try { if ($_.Path) { $c += $_.Path } } catch {} }
    } catch {}
    try {
        $sh = New-Object -ComObject WScript.Shell
        $escritorios = @([Environment]::GetFolderPath('Desktop'))
        try { $escritorios += [Environment]::GetFolderPath('CommonDesktopDirectory') } catch {}
        $escritorios += (Join-Path $env:PUBLIC 'Desktop')
        foreach ($d in $escritorios) {
            if ($d -and (Test-Path -LiteralPath $d)) {
                Get-ChildItem -LiteralPath $d -Filter '*.lnk' -ErrorAction SilentlyContinue | ForEach-Object {
                    try {
                        $t = $sh.CreateShortcut($_.FullName).TargetPath
                        if ($t -and ($t -like '*.exe') -and ((Split-Path -Leaf $t) -like 'Caja*')) { $c += $t }
                    } catch {}
                }
            }
        }
    } catch {}
    $c += 'C:\CajaMery\CajaMeryJane.exe'
    foreach ($p in $c) {
        if ($p -and (Test-Path -LiteralPath $p) -and ((Split-Path -Leaf $p) -notlike '*_new*') -and ((Split-Path -Leaf $p) -notlike '*_anterior*')) {
            return (Resolve-Path -LiteralPath $p).Path
        }
    }
    return $null
}

function Leer-Red($redPath) {
    if (Test-Path -LiteralPath $redPath) {
        try { return ([IO.File]::ReadAllText($redPath) | ConvertFrom-Json) } catch {}
    }
    return $null
}

# Procesos de la caja de ESTA carpeta (nunca se cierra otra caja por el nombre)
function Procesos-Caja($dir, $nombreProc) {
    $r = @()
    foreach ($p in @(Get-Process -Name $nombreProc -ErrorAction SilentlyContinue)) {
        $ruta = $null
        try { $ruta = $p.Path } catch {}
        if (-not $ruta) {
            # Sin permiso para ver la ruta (la abrieron como administrador): en el local es esta
            if (-not $PRUEBA) { $r += $p }
            continue
        }
        try { if ((Split-Path -Parent $ruta) -eq $dir) { $r += $p } } catch {}
    }
    return ,$r
}

function Cerrar-Caja($dir, $nombreProc) {
    foreach ($p in (Procesos-Caja $dir $nombreProc)) {
        try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch {}
    }
}

function Servidor-Responde {
    try {
        $wr = [Net.WebRequest]::Create('http://127.0.0.1:' + $PUERTO_CAJA + '/db/version')
        $wr.Timeout = 3000
        $resp = $wr.GetResponse()
        $resp.Close()
        return $true
    } catch [Net.WebException] {
        # Contesto algo (aunque sea "no autorizado"): el servidor de la caja esta andando
        if ($_.Exception.Response) { return $true }
        return $false
    } catch { return $false }
}

# --- Lector de la base, solo lectura (el SQLite que ya trae Windows) ---
$CS = @'
using System;
using System.Runtime.InteropServices;
using System.Text;

public class MJLeerConfig {
    const string L = "winsqlite3.dll";
    [DllImport(L, CallingConvention = CallingConvention.Winapi)] static extern int sqlite3_open_v2(byte[] f, out IntPtr db, int flags, IntPtr vfs);
    [DllImport(L, CallingConvention = CallingConvention.Winapi)] static extern int sqlite3_close(IntPtr db);
    [DllImport(L, CallingConvention = CallingConvention.Winapi)] static extern int sqlite3_busy_timeout(IntPtr db, int ms);
    [DllImport(L, CallingConvention = CallingConvention.Winapi, CharSet = CharSet.Unicode)] static extern int sqlite3_prepare16_v2(IntPtr db, string sql, int n, out IntPtr st, IntPtr tail);
    [DllImport(L, CallingConvention = CallingConvention.Winapi, CharSet = CharSet.Unicode)] static extern int sqlite3_bind_text16(IntPtr st, int i, string v, int n, IntPtr destructor);
    [DllImport(L, CallingConvention = CallingConvention.Winapi)] static extern int sqlite3_step(IntPtr st);
    [DllImport(L, CallingConvention = CallingConvention.Winapi)] static extern int sqlite3_finalize(IntPtr st);
    [DllImport(L, CallingConvention = CallingConvention.Winapi)] static extern IntPtr sqlite3_column_text16(IntPtr st, int i);

    // flags 1 = solo lectura; 2 = lectura/escritura sin crear (solo se usa para SELECT,
    // por si la base esta en modo WAL sin su archivo -shm y la lectura pura no abre).
    public static string Valor(string path, string clave, int flags) {
        IntPtr db;
        if (sqlite3_open_v2(Encoding.UTF8.GetBytes(path + "\0"), out db, flags, IntPtr.Zero) != 0) {
            if (db != IntPtr.Zero) sqlite3_close(db);
            return null;
        }
        try {
            sqlite3_busy_timeout(db, 10000);
            IntPtr st;
            if (sqlite3_prepare16_v2(db, "SELECT valor FROM app_config WHERE clave = ?", -1, out st, IntPtr.Zero) != 0) return null;
            try {
                sqlite3_bind_text16(st, 1, clave, -1, new IntPtr(-1));
                if (sqlite3_step(st) != 100) return null;
                IntPtr p = sqlite3_column_text16(st, 0);
                return p == IntPtr.Zero ? null : Marshal.PtrToStringUni(p);
            } finally { sqlite3_finalize(st); }
        } finally { sqlite3_close(db); }
    }
}
'@

function Leer-Config($db, $clave) {
    $v = $null
    try { $v = [MJLeerConfig]::Valor($db, $clave, 1) } catch {}
    if ($null -eq $v) { try { $v = [MJLeerConfig]::Valor($db, $clave, 2) } catch {} }
    return $v
}

# Nombre del local, bot de Telegram y como se va a llamar la PC en Tailscale
function Datos-Local($dir) {
    $r = @{ nombre = ''; equipo = ''; db = (Join-Path $dir 'ventas_cobros.db') }
    if (Test-Path -LiteralPath $r.db) {
        try { Add-Type -TypeDefinition $CS -Language CSharp } catch {}
        $r.nombre = [string](Leer-Config $r.db 'nombre_local')
        $bot = Leer-Config $r.db 'telegram_bot_token'
        if ($bot) { $script:BOT = ([string]$bot).Trim() }
    }
    # Que local es: el de la web (dashboard_config.json) y si no, el nombre de la caja
    $lid = ''
    $dash = Join-Path $dir 'dashboard_config.json'
    if (Test-Path -LiteralPath $dash) {
        try { $lid = [string]([IO.File]::ReadAllText($dash) | ConvertFrom-Json).locale_id } catch {}
    }
    if (-not $LOCALES.ContainsKey($lid)) {
        $n = ($r.nombre).ToLower()
        if ($n -like '*previa*' -or $n -like '*guernica*') { $lid = 'guernica' }
        elseif ($n -like '*de la h*') { $lid = 'delah' }
        elseif ($n -like '*korn*') { $lid = 'korn' }
        elseif ($n -like '*vicente*') { $lid = 'sanvicente' }
    }
    if ($LOCALES.ContainsKey($lid)) {
        $r.equipo = $LOCALES[$lid].equipo
        $script:LOCAL = 'Mery Jane ' + $LOCALES[$lid].nombre
    } else {
        $slug = (($r.nombre).ToLower() -replace '^mery jane', '' -replace '[^a-z0-9]+', '-').Trim('-')
        if (-not $slug) { $slug = $env:COMPUTERNAME.ToLower() }
        $r.equipo = 'mery-' + $slug
        if ($r.nombre) { $script:LOCAL = $r.nombre }
    }
    return $r
}

# --- Tailscale ---
function TS-Estado {
    $ErrorActionPreference = 'Continue'
    try {
        $raw = (& $TS status --json 2>$null) | Out-String
        if (-not $raw.Trim()) { return $null }
        return ($raw | ConvertFrom-Json)
    } catch { return $null }
}

function TS-Red($st) {
    try { if ($st.CurrentTailnet -and $st.CurrentTailnet.Name) { return [string]$st.CurrentTailnet.Name } } catch {}
    try {
        $u = $st.User.([string]$st.Self.UserID)
        if ($u -and $u.LoginName) { return [string]$u.LoginName }
    } catch {}
    return ''
}

function Es-Red-De-Nico($nombre) {
    return ((Huella ([string]$nombre).Trim().ToLower()) -eq $HUELLA_RED_NICO)
}

function TS-IP($st) {
    try { foreach ($ip in @($st.Self.TailscaleIPs)) { if ("$ip" -match '^100\.') { return "$ip" } } } catch {}
    try { foreach ($ip in @($st.TailscaleIPs)) { if ("$ip" -match '^100\.') { return "$ip" } } } catch {}
    return ''
}

function TS-Correr([string[]]$argumentos) {
    $ErrorActionPreference = 'Continue'
    $salida = (& $TS @argumentos 2>&1) | Out-String
    return @{ ok = ($LASTEXITCODE -eq 0); texto = $salida.Trim() }
}

function Guardar-Resultado($h) {
    $f = [string]$env:CAJA_RESULTADO
    if (-not $f) { return }
    try { [IO.File]::WriteAllText($f, ([pscustomobject]$h | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false))) } catch {}
}

function Falla-Conexion($m) {
    Write-Host ''
    Write-Host '==========================================================' -ForegroundColor Red
    Write-Host ' NO QUEDO CONECTADO (la caja igual se actualiza)' -ForegroundColor Red
    Write-Host '==========================================================' -ForegroundColor Red
    Write-Host $m
    Write-Host ''
    Write-Host 'Sacale una foto a esta pantalla para Nico y apreta una tecla para seguir.'
    [void](Telegram ((T '\u26a0\ufe0f Conexi\u00f3n a distancia de ') + $script:LOCAL + (T ': no qued\u00f3.') + "`n`n" + $m))
    Guardar-Resultado @{ ok = $false; motivo = $m }
    exit 1
}

function Instalar-Tailscale {
    $arq = 'amd64'
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arq = 'arm64' }
    elseif (-not [Environment]::Is64BitOperatingSystem) { $arq = 'x86' }
    $msi = Join-Path $env:TEMP ('tailscale-setup-' + $arq + '.msi')
    $url = 'https://pkgs.tailscale.com/stable/tailscale-setup-latest-' + $arq + '.msi'
    Write-Host ('Bajando Tailscale (unos 40 MB, puede tardar un par de minutos)...')
    if (Test-Path -LiteralPath $msi) { Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue }
    $bajo = $false
    if ($CURL) {
        $ErrorActionPreference = 'Continue'
        & $CURL -s -L --fail --connect-timeout 20 --max-time 900 -o $msi $url 2>$null
        $bajo = ($LASTEXITCODE -eq 0)
        $ErrorActionPreference = 'Stop'
    }
    if (-not $bajo) {
        try { (New-Object Net.WebClient).DownloadFile($url, $msi); $bajo = $true } catch {}
    }
    if (-not $bajo -or -not (Test-Path -LiteralPath $msi) -or ((Get-Item -LiteralPath $msi).Length -lt 10MB)) {
        Falla-Conexion 'No pude bajar Tailscale. Revisa que haya internet y que la FECHA y HORA de la PC esten bien, y volve a abrir este archivo.'
    }
    # Que sea el instalador oficial: firma digital valida de Tailscale
    $firma = Get-AuthenticodeSignature -LiteralPath $msi
    $quien = ''
    try { $quien = [string]$firma.SignerCertificate.Subject } catch {}
    if ($firma.Status -ne 'Valid' -or $quien -notlike '*Tailscale*') {
        Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue
        Falla-Conexion ('El instalador bajado no tiene la firma de Tailscale (' + $firma.Status + '). No instale nada.')
    }
    Write-Host '  Descargado y verificado (firma oficial de Tailscale).'
    if ($PRUEBA) { Write-Host '[PRUEBA] No se instala.' -ForegroundColor DarkGray; return }
    Write-Host 'Instalando Tailscale...'
    # Queda prendido aunque nadie inicie sesion en Windows, se actualiza solo,
    # NO cambia el internet del local (sin DNS ni rutas de Tailscale) y no abre pantallas.
    $props = @('/i', ('"' + $msi + '"'), '/quiet', '/norestart',
               'TS_UNATTENDEDMODE=always', 'TS_INSTALLUPDATES=always', 'TS_ENABLEDNS=never',
               'TS_ENABLESUBNETS=never', 'TS_ADVERTISEEXITNODE=never', 'TS_ALLOWINCOMINGCONNECTIONS=always',
               'TS_ONBOARDING_FLOW=hide', 'TS_NOLAUNCH=1')
    $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList $props -PassThru
    $p.WaitForExit()
    if ($p.ExitCode -ne 0 -and $p.ExitCode -ne 3010 -and $p.ExitCode -ne 1641) {
        Falla-Conexion ('No se pudo instalar Tailscale (codigo ' + $p.ExitCode + ').')
    }
    Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue
    Write-Host '  Instalado.'
}

# --- Descargas para la actualizacion ---
function Bajar($url, $destino, $extra) {
    # 1) curl de Windows (usa los mismos certificados que el navegador)
    if ($CURL) {
        if (Test-Path -LiteralPath $destino) { Remove-Item -LiteralPath $destino -Force }
        $curlArgs = @('-L', '--fail', '-sS', '-C', '-', '--retry', '5', '--retry-delay', '3',
                  '--connect-timeout', '20', '-A', 'CajaMery-Actualizar', '-o', $destino)
        if ($extra) { $curlArgs += $extra }
        $curlArgs += $url
        $ErrorActionPreference = 'Continue'
        & $CURL @curlArgs
        $codigo = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
        if ($codigo -eq 0 -and (Test-Path -LiteralPath $destino)) { return $true }
        Log ('  curl fallo (codigo ' + $codigo + '), pruebo de otra forma...')
    }
    # 2) PowerShell
    try {
        $wc = New-Object Net.WebClient
        $wc.Headers.Add('User-Agent', 'CajaMery-Actualizar')
        $wc.DownloadFile($url, $destino)
        return (Test-Path -LiteralPath $destino)
    } catch {
        Log ('  ' + $_.Exception.Message)
        return $false
    }
}

function Sha256($archivo) {
    $fs = [IO.File]::Open($archivo, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    try {
        $sha = [Security.Cryptography.SHA256]::Create()
        return (($sha.ComputeHash($fs) | ForEach-Object { $_.ToString('x2') }) -join '')
    } finally { $fs.Close() }
}

# Baja la ultima version, cierra la caja, cambia el exe y la vuelve a abrir.
# Devuelve @{ ok; version; ya; motivo }.
function Actualizar($exe) {
    $dir = Split-Path -Parent $exe
    $nombreProc = [IO.Path]::GetFileNameWithoutExtension($exe)

    Log 'Consultando la ultima version...'
    $tmpJson = Join-Path $env:TEMP 'caja_mery_version.json'
    $ok = Bajar ('https://api.github.com/repos/' + $OWNER + '/' + $REPO + '/contents/version.json?ref=main') $tmpJson @('-H', 'Accept: application/vnd.github.raw')
    if (-not $ok) {
        $ok = Bajar ('https://raw.githubusercontent.com/' + $OWNER + '/' + $REPO + '/main/version.json') $tmpJson $null
    }
    if (-not $ok) {
        return @{ ok = $false; motivo = ('No me pude conectar con GitHub. Revisa que haya internet y que la FECHA y HORA de la PC esten bien ' +
                                         '(si la fecha esta mal, Windows rechaza la conexion).') }
    }
    $manif = [IO.File]::ReadAllText($tmpJson)
    $version = ([regex]::Match($manif, '"version"\s*:\s*(\d+)')).Groups[1].Value
    $sha     = ([regex]::Match($manif, '"sha256"\s*:\s*"([0-9a-fA-F]+)"')).Groups[1].Value.ToLower()
    $tag     = ([regex]::Match($manif, '"tag"\s*:\s*"([^"]+)"')).Groups[1].Value
    $exeName = ([regex]::Match($manif, '"exe"\s*:\s*"([^"]+)"')).Groups[1].Value
    if (-not $tag) { $tag = 'v' + $version }
    if (-not $exeName) { $exeName = 'CajaMeryJane.exe' }
    if (-not $version -or -not $sha) { return @{ ok = $false; motivo = ('La respuesta de GitHub vino rara: ' + $manif) } }
    Log ('Ultima version: v' + $version)

    $shaActual = ''
    try { $shaActual = Sha256 $exe } catch {}
    if ($shaActual -eq $sha) {
        Log ('Esta PC ya tiene la ultima version (v' + $version + '): no hace falta bajar nada.')
        return @{ ok = $true; version = $version; ya = $true }
    }

    # Bajar el programa nuevo
    $part = Join-Path $dir 'CajaMeryJane_manual.part'
    Log 'Descargando el programa nuevo (unos 37 MB, puede tardar)...'
    $url = 'https://github.com/' + $OWNER + '/' + $REPO + '/releases/download/' + $tag + '/' + $exeName
    try {
        $ok = Bajar $url $part $null
    } catch {
        return @{ ok = $false; motivo = ('No pude guardar en ' + $dir + ': ' + $_.Exception.Message +
                                         '. Cerra esta ventana y abri el archivo con click derecho > Ejecutar como administrador.') }
    }
    if (-not $ok) { return @{ ok = $false; motivo = 'No se pudo descargar el programa. Revisa internet y volve a abrir este archivo.' } }
    Start-Sleep -Seconds 2
    if (-not (Test-Path -LiteralPath $part)) {
        return @{ ok = $false; motivo = ('El antivirus borro el programa recien descargado. En Seguridad de Windows > Proteccion antivirus > ' +
                                         'Exclusiones, agrega la carpeta ' + $dir + ' y volve a abrir este archivo.') }
    }
    $shaReal = Sha256 $part
    if ($shaReal -ne $sha) {
        Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
        return @{ ok = $false; motivo = 'El archivo llego danado (se corto la descarga). Volve a abrir este archivo para reintentar.' }
    }
    Log 'Descarga OK y verificada.'

    # Cerrar el programa
    if ((Procesos-Caja $dir $nombreProc).Count -gt 0) {
        Write-Host ''
        Write-Host 'La Caja Mery esta abierta: se cierra un ratito para actualizar y se vuelve a abrir sola.' -ForegroundColor Yellow
        Write-Host 'Si estan cobrando algo, terminalo primero. El turno y las ventas no se pierden.' -ForegroundColor Yellow
        if ($env:CAJA_CONFIRMA) { Write-Host '[PRUEBA] ENTER automatico.' -ForegroundColor DarkGray }
        else { Read-Host 'Presiona ENTER para seguir' | Out-Null }
        # Se cierra de golpe (la base no se dania): si se le pide "cerrar" con el
        # cartel de "Actualizacion disponible" en pantalla, el programa viejo
        # arranca SU actualizacion y se pisa con esta.
        Cerrar-Caja $dir $nombreProc
        Start-Sleep -Seconds 3
    }
    # Restos de un intento anterior del actualizador del programa
    foreach ($resto in @('CajaMeryJane_new.exe', 'CajaMeryJane_new.part', '_update_caja.bat')) {
        Remove-Item -LiteralPath (Join-Path $dir $resto) -Force -ErrorAction SilentlyContinue
    }

    # Cambiar el exe viejo por el nuevo
    $anterior = Join-Path $dir 'CajaMeryJane_anterior.exe'
    $movido = $false
    for ($i = 0; $i -lt 20; $i++) {
        try {
            if (Test-Path -LiteralPath $anterior) { Remove-Item -LiteralPath $anterior -Force }
            Move-Item -LiteralPath $exe -Destination $anterior -Force
            $movido = $true
            break
        } catch {
            Cerrar-Caja $dir $nombreProc
            Start-Sleep -Seconds 1
        }
    }
    if (-not $movido) {
        return @{ ok = $false; motivo = ('Windows no me deja reemplazar ' + $exe + '. Reinicia la PC y volve a abrir este archivo, ' +
                                         'o abrilo con click derecho > Ejecutar como administrador.') }
    }
    try {
        Move-Item -LiteralPath $part -Destination $exe -Force
    } catch {
        Move-Item -LiteralPath $anterior -Destination $exe -Force -ErrorAction SilentlyContinue
        return @{ ok = $false; motivo = ('No pude poner el programa nuevo: ' + $_.Exception.Message + '. Quedo la version anterior.') }
    }
    Log ('Programa reemplazado (el viejo quedo como ' + (Split-Path -Leaf $anterior) + ').')

    # Abrirlo y confirmar que arranco. El programa escribe _run_ok.flag apenas
    # arranca bien. Si no aparece (el antivirus a veces traba el primer arranque
    # de un exe recien bajado), se cierra y se reintenta.
    if ($PRUEBA) {
        Write-Host '[PRUEBA] No se abre el programa.' -ForegroundColor DarkGray
        return @{ ok = $true; version = $version; ya = $false }
    }
    $flag = Join-Path $dir '_run_ok.flag'
    $arranco = $false
    for ($intento = 1; $intento -le 3 -and -not $arranco; $intento++) {
        Remove-Item -LiteralPath $flag -Force -ErrorAction SilentlyContinue
        Log ('Abriendo Caja Mery v' + $version + '...')
        Start-Process -FilePath $exe -WorkingDirectory $dir
        for ($s = 0; $s -lt 40; $s++) {
            Start-Sleep -Seconds 1
            if (Test-Path -LiteralPath $flag) { $arranco = $true; break }
        }
        if (-not $arranco -and $intento -lt 3) {
            Log '  No termino de arrancar, reintento...'
            Cerrar-Caja $dir $nombreProc
            Start-Sleep -Seconds 3
        }
    }
    if (-not $arranco) {
        Log 'El programa nuevo tarda en abrir. Si no aparece, abrilo desde el icono del escritorio.'
        Log 'Si no abre de ninguna forma: borra CajaMeryJane.exe y renombra CajaMeryJane_anterior.exe a CajaMeryJane.exe.'
    }
    return @{ ok = $true; version = $version; ya = $false; arranco = $arranco }
}

# ============================================================================
# PASO "conectar": corre en la ventana de administrador que abre el paso
# principal. Instala y conecta Tailscale, abre el firewall y deja la caja como
# "servidor". No reinicia la caja: eso lo hace la actualizacion.
# ============================================================================
if ($PASO -eq 'conectar') {
    Write-Host ''
    Write-Host '======================================================' -ForegroundColor Cyan
    Write-Host '  CONECTAR LA CAJA PARA QUE NICO ENTRE A DISTANCIA' -ForegroundColor Cyan
    Write-Host '======================================================' -ForegroundColor Cyan
    Write-Host ''

    $dir = [string]$env:CAJA_DIR
    if (-not $dir -or -not (Test-Path -LiteralPath $dir)) {
        $e = Buscar-Exe
        if ($e) { $dir = Split-Path -Parent $e } else { $dir = '' }
    }
    if (-not $dir) { Falla-Conexion 'No encontre la carpeta de la Caja Mery.' }

    $redPath = Join-Path $dir 'red_config.json'
    $red = Leer-Red $redPath
    $modo = 'local'
    if ($red -and $red.modo) { $modo = [string]$red.modo }
    if ($modo -eq 'cliente') {
        Falla-Conexion 'Esta PC es una caja SECUNDARIA: no cambie nada. La conexion se hace en la PC PRINCIPAL del local, la que tiene la base.'
    }
    $d = Datos-Local $dir
    if (-not (Test-Path -LiteralPath $d.db)) {
        Falla-Conexion 'No encontre la base de la caja (ventas_cobros.db) al lado del programa. Esto se hace en la PC PRINCIPAL del local.'
    }
    $equipo = $d.equipo
    if ($d.nombre) { Write-Host ('Local: ' + $d.nombre) }
    if ([Environment]::OSVersion.Version.Major -lt 10) {
        Falla-Conexion 'Esta PC tiene un Windows viejo (anterior a Windows 10) y Tailscale no anda ahi.'
    }

    # --- Tailscale instalado ---
    Write-Host ''
    if (-not (Test-Path -LiteralPath $TS)) {
        Instalar-Tailscale
        if ($PRUEBA -and -not (Test-Path -LiteralPath $TS)) { Falla-Conexion '[PRUEBA] Falta el tailscale de prueba (CAJA_TS).' }
    } else {
        Write-Host 'Tailscale ya estaba instalado.'
    }
    if (-not $PRUEBA) {
        # Las mismas reglas que pone el instalador, por si ya estaba instalado de antes
        try {
            $pol = 'HKLM:\SOFTWARE\Policies\Tailscale'
            if (-not (Test-Path $pol)) { New-Item -Path $pol -Force | Out-Null }
            Set-ItemProperty -Path $pol -Name 'UnattendedMode' -Value 'always'
            Set-ItemProperty -Path $pol -Name 'UseTailscaleDNSSettings' -Value 'never'
            Set-ItemProperty -Path $pol -Name 'UseTailscaleSubnets' -Value 'never'
            Set-ItemProperty -Path $pol -Name 'InstallUpdates' -Value 'always'
        } catch {}
        try { Set-Service -Name 'Tailscale' -StartupType Automatic -ErrorAction SilentlyContinue; Start-Service -Name 'Tailscale' -ErrorAction SilentlyContinue } catch {}
    }

    Write-Host 'Esperando que Tailscale arranque...'
    $st = $null
    for ($i = 0; $i -lt 40; $i++) {
        $st = TS-Estado
        if ($st -and $st.BackendState -and $st.BackendState -ne 'NoState') { break }
        Start-Sleep -Seconds 2
    }
    if (-not $st) { Falla-Conexion 'Tailscale quedo instalado pero no arranca. Reinicia la PC y volve a abrir este archivo.' }

    # --- Que quede en la red de Nico ---
    $redTs = TS-Red $st
    if ($redTs -and -not (Es-Red-De-Nico $redTs)) {
        Falla-Conexion ('En esta PC Tailscale ya esta conectado a OTRA cuenta (' + $redTs + '). No toque nada: avisale a Nico.')
    }

    if ($st.BackendState -eq 'Running') {
        Write-Host 'Esta PC ya estaba conectada a la red de Nico.'
        [void](TS-Correr @('set', '--unattended', '--accept-dns=false', ('--hostname=' + $equipo)))
    } else {
        Write-Host 'Pidiendo el link para que Nico acepte esta PC...'
        $outF = Join-Path $env:TEMP 'mery_ts_up_salida.txt'
        $errF = Join-Path $env:TEMP 'mery_ts_up_errores.txt'
        foreach ($f in @($outF, $errF)) { if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue } }
        $up = Start-Process -FilePath $TS -ArgumentList @('up', '--reset', '--unattended', '--accept-dns=false', ('--hostname=' + $equipo)) `
              -NoNewWindow -PassThru -RedirectStandardOutput $outF -RedirectStandardError $errF
        $link = ''
        for ($i = 0; $i -lt 45 -and -not $link; $i++) {
            Start-Sleep -Seconds 2
            $txt = ''
            foreach ($f in @($outF, $errF)) {
                try { if (Test-Path -LiteralPath $f) { $txt += [IO.File]::ReadAllText($f) + "`n" } } catch {}
            }
            $m = [regex]::Match($txt, 'https://login\.tailscale\.com/[A-Za-z0-9/_\-]+')
            if ($m.Success) { $link = $m.Value; break }
            $st = TS-Estado
            if ($st -and $st.AuthURL) { $link = [string]$st.AuthURL; break }
            if ($st -and $st.BackendState -eq 'Running') { break }
            if ($up.HasExited -and $i -gt 3) {
                $st = TS-Estado
                if ($st -and $st.AuthURL) { $link = [string]$st.AuthURL }
                if (-not $link -and -not ($st -and $st.BackendState -eq 'Running')) {
                    Falla-Conexion ('Tailscale no dio el link para entrar. Detalle: ' + $txt.Trim())
                }
                break
            }
        }
        $st = TS-Estado
        if (-not $link -and -not ($st -and $st.BackendState -eq 'Running')) {
            Falla-Conexion 'Tailscale no dio el link para entrar (tardo demasiado). Volve a abrir este archivo.'
        }

        if ($link) {
            $msg = (T '\ud83d\udef0\ufe0f ') + $script:LOCAL + (T ' quiere conectarse para que entres a la caja a distancia.') + "`n`n" +
                   (T 'Toc\u00e1 este link y acept\u00e1 con tu cuenta de Tailscale:') + "`n" + $link + "`n`n" +
                   (T 'PC: ') + $env:COMPUTERNAME + (T ' \u2192 va a aparecer como ') + $equipo + "`n" +
                   (T 'Si no lo pediste vos, no lo toques.')
            $mando = Telegram $msg
            Write-Host ''
            Write-Host '======================================================' -ForegroundColor Yellow
            if ($mando) {
                Write-Host ' A NICO LE LLEGO UN LINK AL TELEGRAM.' -ForegroundColor Yellow
                Write-Host ' Avisale que lo toque y acepte. Esta ventana espera.' -ForegroundColor Yellow
            } else {
                Write-Host ' MANDALE A NICO UNA FOTO DE ESTE LINK:' -ForegroundColor Yellow
            }
            Write-Host '======================================================' -ForegroundColor Yellow
            Write-Host ''
            Write-Host ('   ' + $link)
            Write-Host ''
            try { Set-Clipboard -Value $link } catch {}
            Write-Host 'Esperando que Nico acepte (no cierres esta ventana)...'
        }

        $listo = $false
        for ($i = 0; $i -lt 600; $i++) {
            $st = TS-Estado
            if ($st -and $st.BackendState -eq 'Running' -and (TS-IP $st)) { $listo = $true; break }
            if ($i % 5 -eq 4) { Write-Host '.' -NoNewline }
            Start-Sleep -Seconds 2
        }
        Write-Host ''
        if (-not $listo) {
            Falla-Conexion 'Nico todavia no acepto la PC (pasaron 20 minutos). Volve a abrir este archivo cuando el este disponible.'
        }
        try { if (-not $up.HasExited) { $up.WaitForExit(15000) | Out-Null } } catch {}
    }

    $st = TS-Estado
    $redTs = TS-Red $st
    if ($redTs -and -not (Es-Red-De-Nico $redTs)) {
        [void](TS-Correr @('logout'))
        Falla-Conexion ('La PC se conecto a una cuenta que NO es la de Nico (' + $redTs + '). La desconecte. Volve a abrir el archivo y que acepte Nico.')
    }
    $ipTs = TS-IP $st
    Write-Host ('  Conectada a la red de Nico como ' + $equipo + ' (' + $ipTs + ').') -ForegroundColor Green

    # --- Firewall: solo los puertos de la caja (base 5555 e impresion 8080), solo desde esa red ---
    if ($PRUEBA) {
        Write-Host '[PRUEBA] No se toca el firewall.' -ForegroundColor DarkGray
    } else {
        $ErrorActionPreference = 'Continue'
        & netsh advfirewall firewall delete rule ('name=' + $REGLA_FW) | Out-Null
        & netsh advfirewall firewall add rule ('name=' + $REGLA_FW) dir=in action=allow protocol=TCP localport=5555,8080 remoteip=100.64.0.0/10 profile=any | Out-Null
        $fwOk = ($LASTEXITCODE -eq 0)
        try {
            Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { $_.InterfaceAlias -like '*Tailscale*' -and $_.NetworkCategory -eq 'Public' } |
                ForEach-Object { Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private -ErrorAction SilentlyContinue }
        } catch {}
        $ErrorActionPreference = 'Stop'
        if ($fwOk) { Write-Host '  Firewall listo.' } else { Write-Host '  No pude agregar la regla del firewall (puede que igual ande).' -ForegroundColor Yellow }
    }

    # --- La caja tiene que estar como PC principal ("servidor") ---
    $claveTxt = 'la de siempre'
    if ($red -and $red.token -and ([string]$red.token).Trim() -and ((Huella ([string]$red.token).Trim()) -ne $HUELLA_CLAVE)) { $claveTxt = 'DISTINTA a la de siempre' }
    $cambioModo = $false
    if ($modo -ne 'servidor') {
        Write-Host ''
        Write-Host 'La caja de esta PC estaba en modo "local": la paso a "servidor" para que Nico pueda entrar.'
        try {
            if (Test-Path -LiteralPath $redPath) {
                Copy-Item -LiteralPath $redPath -Destination (Join-Path $dir 'red_config_antes_distancia.json') -Force
            }
            if (-not $red) {
                $red = [pscustomobject]@{ modo = 'servidor'; servidor_ip = ''; puerto = $PUERTO_CAJA; caja_ciega = $false; impresora_modo = 'servidor'; impresora_local = '' }
            }
            if ($red.PSObject.Properties['modo']) { $red.modo = 'servidor' } else { $red | Add-Member -NotePropertyName modo -NotePropertyValue 'servidor' }
            [IO.File]::WriteAllText($redPath, ($red | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
        } catch {
            Falla-Conexion ('No pude cambiar la configuracion de red de la caja: ' + $_.Exception.Message)
        }
        Write-Host '  Listo (rige cuando la caja se vuelve a abrir, en la actualizacion).'
        $cambioModo = $true
    }

    Guardar-Resultado @{ ok = $true; equipo = $equipo; ip = $ipTs; clave = $claveTxt; cambio_modo = $cambioModo }
    Write-Host ''
    Write-Host '======================================================' -ForegroundColor Green
    Write-Host ' CONEXION LISTA. Esta ventana se cierra sola.' -ForegroundColor Green
    Write-Host ' Sigue la actualizacion en la otra ventana.' -ForegroundColor Green
    Write-Host '======================================================' -ForegroundColor Green
    exit 0
}

# ============================================================================
# PASO PRINCIPAL
# ============================================================================
Write-Host ''
Write-Host '=========================================' -ForegroundColor Cyan
Write-Host '   ACTUALIZAR Y CONECTAR LA CAJA MERY' -ForegroundColor Cyan
Write-Host '=========================================' -ForegroundColor Cyan
Write-Host ''

$exe = Buscar-Exe
if (-not $exe) {
    Write-Host ''
    Write-Host '==========================================================' -ForegroundColor Red
    Write-Host ' NO ENCONTRE LA CAJA MERY' -ForegroundColor Red
    Write-Host '==========================================================' -ForegroundColor Red
    Write-Host ('Copia este archivo en la misma carpeta que CajaMeryJane.exe (click derecho en el icono de Caja Mery ' +
                'del escritorio > Abrir ubicacion del archivo) y volve a abrirlo.')
    Write-Host ''
    Write-Host 'Mandale una foto de esta pantalla a Nico.'
    exit 1
}
$dir = Split-Path -Parent $exe
$nombreProc = [IO.Path]::GetFileNameWithoutExtension($exe)
$script:logFile = Join-Path $dir 'actualizar_log.txt'
Log ('Programa encontrado en: ' + $exe)

$red = Leer-Red (Join-Path $dir 'red_config.json')
$modo = 'local'
if ($red -and $red.modo) { $modo = [string]$red.modo }
$principal = ($modo -ne 'cliente')
if ($principal) {
    $d = Datos-Local $dir
    if ($d.nombre) { Write-Host ('Local: ' + $d.nombre) }
}

Write-Host ''
if ($principal) {
    Write-Host ('Esto hace dos cosas en la PC principal de ' + $script:LOCAL + ':') -ForegroundColor Yellow
    Write-Host '  1. La deja lista para que Nico entre a la caja desde su casa.' -ForegroundColor Yellow
    Write-Host '  2. Actualiza la Caja Mery a la ultima version.' -ForegroundColor Yellow
    Write-Host 'No toca las ventas ni el turno. Para actualizar, la caja se cierra un ratito (avisa antes).' -ForegroundColor Yellow
    $pregunta = 'Si esta es la PC PRINCIPAL del local, escribi SI y apreta ENTER'
} else {
    $donde = ''
    if ($red.servidor_ip) { $donde = ' (se conecta a ' + $red.servidor_ip + ')' }
    Write-Host ('Esta PC es una caja SECUNDARIA del local' + $donde + ': aca solo se actualiza la Caja Mery.') -ForegroundColor Yellow
    Write-Host 'No toca las ventas ni el turno. Para actualizar, la caja se cierra un ratito (avisa antes).' -ForegroundColor Yellow
    $pregunta = 'Para actualizarla, escribi SI y apreta ENTER'
}
$resp = $env:CAJA_CONFIRMA
if (-not $resp) { $resp = Read-Host $pregunta }
if (("$resp").Trim().ToUpper() -notmatch '^S') {
    Write-Host ''
    Write-Host 'No se cambio nada.'
    exit 0
}

# --- 1. Conexion para Nico (solo en la PC principal, en otra ventana como administrador) ---
$con = $null
if ($principal) {
    Write-Host ''
    Write-Host '--- 1 de 2: conexion para que Nico entre a distancia ---' -ForegroundColor Cyan
    Write-Host 'Se abre otra ventana. Windows va a preguntar si dejas que haga cambios: toca SI.'
    Write-Host 'Si esa ventana muestra un link, es para Nico (le llega al Telegram). Esta ventana espera.'
    $resFile = Join-Path $env:TEMP ('mery_conectar_' + [guid]::NewGuid().ToString('N') + '.json')
    # Se abre cmd.exe (no el .bat) como administrador, con todo entre un par de
    # comillas de mas: "Ejecutar como administrador" de un .bat usa cmd /C "%1" %*
    # y con datos entre comillas cmd se confunde y no arranca (06/11 en Korn).
    $cmd = Join-Path $env:SystemRoot 'System32\cmd.exe'
    $argumentos = '/c ""' + $env:CAJA_BAT + '" conectar "' + $dir + '" "' + $resFile + '""'
    $p = $null
    try {
        if ($PRUEBA) {
            $p = Start-Process -FilePath $cmd -ArgumentList $argumentos -NoNewWindow -PassThru
        } else {
            $p = Start-Process -FilePath $cmd -ArgumentList $argumentos -Verb RunAs -PassThru
        }
    } catch {
        $con = @{ ok = $false; motivo = 'No se dio el permiso de Windows (hay que tocar SI en el cartel). Volve a abrir este archivo para conectarla.' }
    }
    $codigo = ''
    if ($p) { try { $p.WaitForExit(); $codigo = [string]$p.ExitCode } catch {} }
    if (-not $con) {
        try { $con = ([IO.File]::ReadAllText($resFile) | ConvertFrom-Json) } catch {}
        if (-not $con) { $con = @{ ok = $false; motivo = ('La ventana de conexion se cerro antes de terminar (codigo ' + $codigo + '). Volve a abrir este archivo para conectarla.') } }
    }
    Remove-Item -LiteralPath $resFile -Force -ErrorAction SilentlyContinue
    if ($con.ok) { Log ('Conexion para Nico: OK (' + $con.equipo + ' ' + $con.ip + ')') }
    else { Log ('Conexion para Nico: NO quedo. ' + $con.motivo) }
}

# --- 2. Actualizar ---
Write-Host ''
if ($principal) { Write-Host '--- 2 de 2: actualizar la Caja Mery ---' -ForegroundColor Cyan }
$upd = Actualizar $exe
if ($upd.ok) {
    if (-not $upd.ya) { Log ('OK actualizado a v' + $upd.version) }
} else {
    Write-Host ''
    Write-Host ' NO SE PUDO ACTUALIZAR' -ForegroundColor Red
    Log $upd.motivo
}

# --- 3. Que la caja acepte conexiones de Nico (PC principal conectada) ---
$responde = $false
if ($principal -and $con.ok) {
    for ($i = 0; $i -lt 30 -and -not $responde; $i++) {
        $responde = Servidor-Responde
        if (-not $responde) { Start-Sleep -Seconds 2 }
    }
    if (-not $responde -and -not $PRUEBA) {
        if ((Procesos-Caja $dir $nombreProc).Count -gt 0) {
            Write-Host ''
            Write-Host '======================================================' -ForegroundColor Yellow
            Write-Host ' FALTA UNA COSA: cerra la Caja Mery y volvela a abrir' -ForegroundColor Yellow
            Write-Host ' (cuando no estes cobrando). Esta ventana te espera.' -ForegroundColor Yellow
            Write-Host '======================================================' -ForegroundColor Yellow
            for ($i = 0; $i -lt 300 -and -not $responde; $i++) {
                Start-Sleep -Seconds 2
                $responde = Servidor-Responde
                if ($i % 5 -eq 4) { Write-Host '.' -NoNewline }
            }
            Write-Host ''
        } else {
            Write-Host 'La Caja Mery esta cerrada: la abro...'
            try { Start-Process -FilePath $exe -WorkingDirectory $dir } catch {}
            for ($i = 0; $i -lt 60 -and -not $responde; $i++) { Start-Sleep -Seconds 2; $responde = Servidor-Responde }
        }
    }
}

# --- Aviso a Nico y resumen ---
if ($principal) {
    $partes = @()
    if ($upd.ok -and $upd.ya) { $partes += (T 'Caja: ya ten\u00eda la \u00faltima versi\u00f3n (v') + $upd.version + ')' }
    elseif ($upd.ok) { $partes += (T 'Caja: actualizada a v') + $upd.version + (T ' \u2705') }
    else { $partes += (T 'Caja: NO se actualiz\u00f3 \u26a0\ufe0f ') + $upd.motivo }
    if ($con.ok) {
        $partes += (T 'Equipo: ') + $con.equipo + ' (' + $con.ip + ')'
        if ($responde) { $partes += (T 'A distancia: ya acepta conexiones \u2705') }
        else { $partes += (T 'A distancia: todav\u00eda no responde, falta cerrar la caja y volver a abrirla \u26a0\ufe0f') }
        $partes += (T 'Clave de red: ') + $con.clave
    } else {
        $partes += (T 'Conexi\u00f3n a distancia: NO qued\u00f3 \u26a0\ufe0f ') + $con.motivo
    }
    $todoOk = ($upd.ok -and $con.ok -and $responde)
    if ($todoOk) { $cab = (T '\u2705 ') + $script:LOCAL + (T ' qued\u00f3 actualizada y conectada para entrar a distancia.') }
    else { $cab = (T '\u26a0\ufe0f ') + $script:LOCAL + (T ': actualizar y conectar qued\u00f3 a medias.') }
    $msg = $cab + "`n`n" + ($partes -join "`n")
    if ($con.ok -and $responde) { $msg += "`n`n" + (T 'Abr\u00ed el \u00edcono de ') + $script:LOCAL + (T ' (a distancia) en tu PC.') }
    [void](Telegram $msg)
}

Write-Host ''
$conOk = (-not $principal) -or ($con.ok -and $responde)
if ($upd.ok -and $conOk) {
    Write-Host '=========================================' -ForegroundColor Green
    if ($principal) { Write-Host (' LISTO: Caja Mery actualizada (v' + $upd.version + ') y conectada para Nico') -ForegroundColor Green }
    else { Write-Host (' LISTO: Caja Mery actualizada a v' + $upd.version) -ForegroundColor Green }
    Write-Host '=========================================' -ForegroundColor Green
    Write-Host 'Ya pueden seguir trabajando normal. Queda andando solo, aunque reinicien la PC.'
} else {
    Write-Host '=========================================' -ForegroundColor Yellow
    Write-Host ' QUEDO A MEDIAS' -ForegroundColor Yellow
    Write-Host '=========================================' -ForegroundColor Yellow
    if ($upd.ok) { Write-Host ('  Actualizacion: OK (v' + $upd.version + ')') } else { Write-Host ('  Actualizacion: NO. ' + $upd.motivo) }
    if ($principal) {
        if (-not $con.ok) { Write-Host ('  Conexion para Nico: NO. ' + $con.motivo) }
        elseif (-not $responde) { Write-Host '  Conexion para Nico: falta cerrar la Caja Mery y volverla a abrir.' }
        else { Write-Host '  Conexion para Nico: OK' }
    }
    Write-Host ''
    Write-Host 'Mandale una foto de esta pantalla a Nico.'
}
if ($principal) {
    Write-Host ''
    Write-Host 'Si en el local hay otra PC con la Caja Mery (caja secundaria), abri este mismo'
    Write-Host 'archivo ahi tambien: en esa solo se actualiza.'
}
