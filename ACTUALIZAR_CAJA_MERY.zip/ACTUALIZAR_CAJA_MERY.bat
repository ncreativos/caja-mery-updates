<# :
@echo off
title Actualizar Caja Mery
set "CAJA_BAT=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:CAJA_BAT); Invoke-Expression $s"
echo.
pause
exit /b
#>

# ---------------------------------------------------------------------------
# Actualizador MANUAL de Caja Mery (para las PCs donde el boton de actualizar
# del programa da error). Doble click y listo:
#   1. Busca donde esta instalado CajaMeryJane.exe
#   2. Baja la ultima version de GitHub con el curl de Windows
#   3. Verifica que llego entera (sha256)
#   4. Cierra el programa, guarda el viejo como CajaMeryJane_anterior.exe,
#      pone el nuevo y lo vuelve a abrir
# La base de datos y la configuracion NO se tocan.
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072 } catch {}

$OWNER = 'ncreativos'
$REPO  = 'caja-mery-updates'
$script:logFile = Join-Path $env:TEMP 'actualizar_caja_mery_log.txt'

function Log($m) {
    Write-Host $m
    try { Add-Content -Path $script:logFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m) } catch {}
}

function Fallo($m) {
    Write-Host ''
    Write-Host '==========================================================' -ForegroundColor Red
    Write-Host ' NO SE PUDO ACTUALIZAR' -ForegroundColor Red
    Write-Host '==========================================================' -ForegroundColor Red
    Log $m
    Write-Host ''
    Write-Host 'Mandale una foto de esta pantalla a Nico.'
    Write-Host ('Registro: ' + $script:logFile)
    exit 1
}

function Buscar-Exe {
    $c = @()
    $c += (Join-Path (Split-Path -Parent $env:CAJA_BAT) 'CajaMeryJane.exe')
    try {
        Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'CajaMery*' } |
            ForEach-Object { try { if ($_.Path) { $c += $_.Path } } catch {} }
    } catch {}
    try {
        $sh = New-Object -ComObject WScript.Shell
        $escritorios = @([Environment]::GetFolderPath('Desktop'))
        try { $escritorios += [Environment]::GetFolderPath('CommonDesktopDirectory') } catch {}
        $escritorios += (Join-Path $env:PUBLIC 'Desktop')
        foreach ($d in $escritorios) {
            if ($d -and (Test-Path -LiteralPath $d)) {
                Get-ChildItem -LiteralPath $d -Filter '*.lnk' -ErrorAction SilentlyContinue | ForEach-Object {
                    try {
                        $t = $sh.CreateShortcut($_.FullName).TargetPath
                        if ($t -and ($t -like '*.exe') -and ((Split-Path -Leaf $t) -like 'Caja*')) { $c += $t }
                    } catch {}
                }
            }
        }
    } catch {}
    $c += 'C:\CajaMery\CajaMeryJane.exe'
    foreach ($p in $c) {
        if ($p -and (Test-Path -LiteralPath $p) -and ((Split-Path -Leaf $p) -notlike '*_new*') -and ((Split-Path -Leaf $p) -notlike '*_anterior*')) {
            return (Resolve-Path -LiteralPath $p).Path
        }
    }
    return $null
}

$CURL = Join-Path $env:SystemRoot 'System32\curl.exe'
if (-not (Test-Path -LiteralPath $CURL)) { $CURL = $null }

function Bajar($url, $destino, $extra) {
    # 1) curl de Windows (usa los mismos certificados que el navegador)
    if ($CURL) {
        if (Test-Path -LiteralPath $destino) { Remove-Item -LiteralPath $destino -Force }
        $curlArgs = @('-L', '--fail', '-sS', '-C', '-', '--retry', '5', '--retry-delay', '3',
                  '--connect-timeout', '20', '-A', 'CajaMery-Actualizar', '-o', $destino)
        if ($extra) { $curlArgs += $extra }
        $curlArgs += $url
        & $CURL @curlArgs
        if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $destino)) { return $true }
        Log ('  curl fallo (codigo ' + $LASTEXITCODE + '), pruebo de otra forma...')
    }
    # 2) PowerShell
    try {
        $wc = New-Object Net.WebClient
        $wc.Headers.Add('User-Agent', 'CajaMery-Actualizar')
        $wc.DownloadFile($url, $destino)
        return (Test-Path -LiteralPath $destino)
    } catch {
        Log ('  ' + $_.Exception.Message)
        return $false
    }
}

function Sha256($archivo) {
    $fs = [IO.File]::OpenRead($archivo)
    try {
        $sha = [Security.Cryptography.SHA256]::Create()
        return (($sha.ComputeHash($fs) | ForEach-Object { $_.ToString('x2') }) -join '')
    } finally { $fs.Close() }
}

Write-Host ''
Write-Host '=========================================' -ForegroundColor Cyan
Write-Host '      ACTUALIZAR CAJA MERY' -ForegroundColor Cyan
Write-Host '=========================================' -ForegroundColor Cyan
Write-Host ''

# --- 1. Donde esta instalado ---
$exe = Buscar-Exe
if (-not $exe) {
    Fallo ('No encontre CajaMeryJane.exe. Copia este archivo en la misma carpeta que CajaMeryJane.exe ' +
           '(click derecho en el icono de Caja Mery del escritorio > Abrir ubicacion del archivo) y volve a abrirlo.')
}
$dir = Split-Path -Parent $exe
$script:logFile = Join-Path $dir 'actualizar_log.txt'
Log ('Programa encontrado en: ' + $exe)

# --- 2. Que version hay en la nube ---
Log 'Consultando la ultima version...'
$tmpJson = Join-Path $env:TEMP 'caja_mery_version.json'
$ok = Bajar ('https://api.github.com/repos/' + $OWNER + '/' + $REPO + '/contents/version.json?ref=main') $tmpJson @('-H', 'Accept: application/vnd.github.raw')
if (-not $ok) {
    $ok = Bajar ('https://raw.githubusercontent.com/' + $OWNER + '/' + $REPO + '/main/version.json') $tmpJson $null
}
if (-not $ok) {
    Fallo ('No me pude conectar con GitHub. Revisa que haya internet y que la FECHA y HORA de la PC esten bien ' +
           '(si la fecha esta mal, Windows rechaza la conexion).')
}
$manif = [IO.File]::ReadAllText($tmpJson)
$version = ([regex]::Match($manif, '"version"\s*:\s*(\d+)')).Groups[1].Value
$sha     = ([regex]::Match($manif, '"sha256"\s*:\s*"([0-9a-fA-F]+)"')).Groups[1].Value.ToLower()
$tag     = ([regex]::Match($manif, '"tag"\s*:\s*"([^"]+)"')).Groups[1].Value
$exeName = ([regex]::Match($manif, '"exe"\s*:\s*"([^"]+)"')).Groups[1].Value
if (-not $tag) { $tag = 'v' + $version }
if (-not $exeName) { $exeName = 'CajaMeryJane.exe' }
if (-not $version -or -not $sha) { Fallo ('La respuesta de GitHub vino rara: ' + $manif) }
Log ('Ultima version: v' + $version)

# --- 3. Bajar el programa nuevo ---
$part = Join-Path $dir 'CajaMeryJane_manual.part'
Log 'Descargando el programa nuevo (unos 30 MB, puede tardar)...'
$url = 'https://github.com/' + $OWNER + '/' + $REPO + '/releases/download/' + $tag + '/' + $exeName
try {
    $ok = Bajar $url $part $null
} catch {
    Fallo ('No pude guardar en ' + $dir + ': ' + $_.Exception.Message +
           '. Cerra esta ventana y abri el archivo con click derecho > Ejecutar como administrador.')
}
if (-not $ok) { Fallo 'No se pudo descargar el programa. Revisa internet y volve a probar.' }
Start-Sleep -Seconds 2
if (-not (Test-Path -LiteralPath $part)) {
    Fallo ('El antivirus borro el programa recien descargado. En Seguridad de Windows > Proteccion antivirus > ' +
           'Exclusiones, agrega la carpeta ' + $dir + ' y volve a probar.')
}
$shaReal = Sha256 $part
if ($shaReal -ne $sha) {
    Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
    Fallo 'El archivo llego danado (se corto la descarga). Volve a abrir este archivo para reintentar.'
}
Log 'Descarga OK y verificada.'

# --- 4. Cerrar el programa ---
$nombreProc = [IO.Path]::GetFileNameWithoutExtension($exe)
$abiertos = @(Get-Process -Name $nombreProc -ErrorAction SilentlyContinue)
if ($abiertos.Count -gt 0) {
    Write-Host ''
    Write-Host 'La Caja Mery esta abierta: se va a cerrar para actualizar.' -ForegroundColor Yellow
    Write-Host 'Si estan cobrando algo, terminalo primero.' -ForegroundColor Yellow
    Read-Host 'Presiona ENTER para seguir' | Out-Null
    # Se cierra de golpe (la base no se dania): si se le pide "cerrar" con el
    # cartel de "Actualizacion disponible" en pantalla, el programa viejo
    # arranca SU actualizacion y se pisa con esta.
    Get-Process -Name $nombreProc -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 3
}
# Restos de un intento anterior del actualizador del programa
foreach ($resto in @('CajaMeryJane_new.exe', 'CajaMeryJane_new.part', '_update_caja.bat')) {
    Remove-Item -LiteralPath (Join-Path $dir $resto) -Force -ErrorAction SilentlyContinue
}

# --- 5. Cambiar el exe viejo por el nuevo ---
$anterior = Join-Path $dir 'CajaMeryJane_anterior.exe'
$movido = $false
for ($i = 0; $i -lt 20; $i++) {
    try {
        if (Test-Path -LiteralPath $anterior) { Remove-Item -LiteralPath $anterior -Force }
        Move-Item -LiteralPath $exe -Destination $anterior -Force
        $movido = $true
        break
    } catch {
        Get-Process -Name $nombreProc -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
    }
}
if (-not $movido) {
    Fallo ('Windows no me deja reemplazar ' + $exe + '. Reinicia la PC y volve a abrir este archivo, ' +
           'o abrilo con click derecho > Ejecutar como administrador.')
}
try {
    Move-Item -LiteralPath $part -Destination $exe -Force
} catch {
    Move-Item -LiteralPath $anterior -Destination $exe -Force -ErrorAction SilentlyContinue
    Fallo ('No pude poner el programa nuevo: ' + $_.Exception.Message + '. Quedo la version anterior.')
}
Log ('Programa reemplazado (el viejo quedo como ' + (Split-Path -Leaf $anterior) + ').')

# --- 6. Abrirlo y confirmar que arranco ---
# El programa escribe _run_ok.flag apenas arranca bien. Si no aparece (el
# antivirus a veces traba el primer arranque de un exe recien bajado), se
# cierra y se reintenta.
$flag = Join-Path $dir '_run_ok.flag'
$arranco = $false
for ($intento = 1; $intento -le 3 -and -not $arranco; $intento++) {
    Remove-Item -LiteralPath $flag -Force -ErrorAction SilentlyContinue
    Log ('Abriendo Caja Mery v' + $version + '...')
    Start-Process -FilePath $exe -WorkingDirectory $dir
    for ($s = 0; $s -lt 40; $s++) {
        Start-Sleep -Seconds 1
        if (Test-Path -LiteralPath $flag) { $arranco = $true; break }
    }
    if (-not $arranco -and $intento -lt 3) {
        Log '  No termino de arrancar, reintento...'
        Get-Process -Name $nombreProc -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
    }
}

Write-Host ''
if ($arranco) {
    Write-Host '=========================================' -ForegroundColor Green
    Write-Host (' LISTO: Caja Mery actualizada a v' + $version) -ForegroundColor Green
    Write-Host '=========================================' -ForegroundColor Green
    Log ('OK actualizado a v' + $version)
} else {
    Log 'El programa nuevo tarda en abrir. Si no aparece, abrilo desde el icono del escritorio.'
    Log ('Si no abre de ninguna forma: borra CajaMeryJane.exe y renombra CajaMeryJane_anterior.exe a CajaMeryJane.exe.')
}
